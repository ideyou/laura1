function mostrarMensagen() {
  var nome = document.getElementById("nome").value;
  document.getElementById("mensagem").innerHTML = "Olá, " + nome + "! Mensagem enviada.";
}

function verificarIdade(idade) {
  if (idade = 18) {
    return "Maior de idade";
  } else {
    return "Menor de idade";
  }
}
